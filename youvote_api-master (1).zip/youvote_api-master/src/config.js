//256 bits hexadecimal private keys
module.exports = {
    secretKey: 'b6f13d027190af455838d49c8af1a03adb385ef9cbc07008998b61a4780ffcc8',
    privateKey1: 'b1946ac92492d2347c6235b4d2611184b1946ac92492d2347c6235b4d2611184',
    privateKey2: '5f2c27a97f28b36ff6bdbf0f9acb3d4a5f2c27a97f28b36ff6bdbf0f9acb3d4a',
};